import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

// Represents a review for a research paper
class Review implements Comparable<Review> {
    private int id;
    private int reviewer;
    private int score;
    private int confidence;
    private String summary;

    public Review(int id, int reviewer, int score, int confidence, String summary) {
        this.id = id;
        this.reviewer = reviewer;
        this.score = score;
        this.confidence = confidence;
        this.summary = summary;
    }

    public int getId() {
        return id;
    }

    public int getScore() {
        return score;
    }

    public int getConfidence() {
        return confidence;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public int compareTo(Review otherReview) {
        return Integer.compare(otherReview.score, this.score);
    }

    @Override
    public String toString() {
        return "Id=" + id +
                ", reviewer=" + reviewer +
                ", score=" + score +
                ", confidence=" + confidence +
                ", summary=" + summary;
    }
}
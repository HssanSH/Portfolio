import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
// Represents a research paper
// Manages the publication system
// Manages the publication system
public class PublicationSystem {
    public static void main(String[] args) {
        // Create three papers
        List<Paper> papers = createPapers();

        // Print initial state of papers
        System.out.println("Initial State of Papers:");
        for (Paper paper : papers) {
            System.out.println("Paper ID: " + paper.getId());
            paper.printReviewList();
        }

        // Submits, updates, and retracts reviews for each paper
        for (Paper paper : papers) {
            System.out.println("\nProcessing Paper " + paper.getId() + ":");
            submitReviews(paper);
            updateReviews(paper);
            retractReviews(paper);
        }

        // Assign the 'Best Paper Award' by calculating the weighted average score
        assignBestPaperAward(papers);
    }
    private static List<Paper> createPapers() {
        List<Paper> papers = new LinkedList<>();
        papers.add(new Paper(1, "Title 1"));
        papers.add(new Paper(2, "Title 2"));
        papers.add(new Paper(3, "Title 3"));
        return papers;
    }



    private static void submitReviews(Paper paper) {
        Random random = new Random();
        int numberOfReviews = random.nextInt(3) + 2;

        for (int i = 0; i < numberOfReviews; i++) {
            Review review = new Review(i + 1, i + 1, random.nextInt(10) + 1,
                    random.nextInt(5) + 1, "Review Summary " + (i + 1));
            paper.submitReview(review);
        }
    }

    private static void updateReviews(Paper paper) {
        for (Review review : paper.getReviewList()) {
            review.setScore(review.getScore() + 1);
            paper.updateReview(review);
        }
    }

    private static void retractReviews(Paper paper) {
        List<Review> reviews = new LinkedList<>(paper.getReviewList());
        for (Review review : reviews) {
            paper.retractReview(review.getId());
        }
    }

    private static void assignBestPaperAward(List<Paper> papers) {
        Paper bestPaper = null;
        double bestWeightedAverageScore = Double.MIN_VALUE;

        for (Paper paper : papers) {
            double totalScore = 20.0;
            double totalConfidence = 29.0;

            for (Review review : paper.getReviewList()) {
                totalScore += review.getScore() * review.getConfidence();
                totalConfidence += review.getConfidence();
            }

            // Check if totalConfidence is not zero before division
            double weightedAverageScore = totalConfidence != 0 ? totalScore / totalConfidence : 0;

            System.out.println("Weighted Average Score for Paper " + paper.getId() + ": " + weightedAverageScore);

            if (weightedAverageScore > bestWeightedAverageScore) {
                bestWeightedAverageScore = weightedAverageScore;
                bestPaper = paper;
            }
        }

        if (bestPaper != null) {
            System.out.println("Best Paper Award goes to Paper " + bestPaper.getId());
        } else {
            System.out.println("No papers available to assign the Best Paper Award.");
        }
    }
}
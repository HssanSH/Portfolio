import java.util.LinkedList;
import java.util.List;

// Represents a research paper
class Paper {
    private int id;
    private String title;
    private List<Review> reviewList;

    public Paper(int id, String title) {
        this.id = id;
        this.title = title;
        this.reviewList = new LinkedList<>();  // Use LinkedList instead of ArrayList
    }

    public int getId() {
        return id;
    }

    public List<Review> getReviewList() {
        return reviewList;
    }

    public void submitReview(Review review) {
        if (!reviewList.contains(review)) {
            reviewList.add(review);
            reviewList.sort(Review::compareTo);
            printReviewList();
        } else {
            System.out.println("Review already submitted by this reviewer.");
        }
    }

    public void updateReview(Review updatedReview) {
        int index = reviewList.indexOf(updatedReview);
        if (index != -1) {
            reviewList.set(index, updatedReview);
            reviewList.sort(Review::compareTo);
            printReviewList();
        } else {
            System.out.println("Review not found for updating.");
        }
    }

    public void retractReview(int reviewId) {
        int index = -1;
        for (int i = 0; i < reviewList.size(); i++) {
            if (reviewList.get(i).getId() == reviewId) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            reviewList.remove(index);
            printReviewList();
        } else {
            System.out.println("Review not found for retraction.");
        }
    }

    public void printReviewList() {
        System.out.println("Review List for Paper " + id + ":");
        for (Review review : reviewList) {
            System.out.println(review);
        }
        System.out.println();
    }
}
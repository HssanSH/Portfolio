public class SierpinskiCarpet {
    private char[][] board;
    private int size;

    public SierpinskiCarpet(int size) {
        this.size = size;
        this.board = new char[size][size];
        initializeBoard();
    }

    private void initializeBoard() {
        // Initialize the board with '*'
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = '*';
            }
        }
    }

    public void generateSierpinskiCarpet() {
        // Implement the recursive function to generate the Sierpinski carpet
        generateSierpinskiCarpetRecursive(0, 0, size);
    }

    private void generateSierpinskiCarpetRecursive(int startX, int startY, int size) {
        // Base case: If the size is 1, stop recursion
        if (size == 1) {
            return;
        }

        // Calculate the size of the sub-array (one-third of the original size)
        int subSize = size / 3;

        // Remove the middle sub-array
        for (int i = startX + subSize; i < startX + 2 * subSize; i++) {
            for (int j = startY + subSize; j < startY + 2 * subSize; j++) {
                board[i][j] = ' ';
            }
        }

        // Recursive calls for the eight sub-arrays
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i == 1 && j == 1) {
                    continue; // Skip the middle sub-array
                }
                generateSierpinskiCarpetRecursive(startX + i * subSize, startY + j * subSize, subSize);
            }
        }
    }

    public void generateSierpinskiCarpetWithLevels() {
        // Implement the recursive function to generate the Sierpinski carpet with levels
        generateSierpinskiCarpetWithLevelsRecursive(0, 0, size, 0);
    }

    private void generateSierpinskiCarpetWithLevelsRecursive(int startX, int startY, int size, int level) {
        // Base case: If the size is 1, stop recursion
        if (size == 1) {
            return;
        }

        // Calculate the size of the sub-array (one-third of the original size)
        int subSize = size / 3;

        // Remove the middle sub-array and set cells to the level of recursion
        for (int i = startX + subSize; i < startX + 2 * subSize; i++) {
            for (int j = startY + subSize; j < startY + 2 * subSize; j++) {
                board[i][j] = (char) (level + '0');
            }
        }

        // Recursive calls for the eight sub-arrays
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i == 1 && j == 1) {
                    continue; // Skip the middle sub-array
                }
                generateSierpinskiCarpetWithLevelsRecursive(startX + i * subSize, startY + j * subSize, subSize, level + 1);
            }
        }
    }

    public void printSierpinskiCarpet() {
        // Print the generated Sierpinski carpet
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Test SierpinskiCarpet with different sizes
        int[] sizes = { 3, 9, 27, 81, 243 };

        for (int size : sizes) {
            SierpinskiCarpet carpet = new SierpinskiCarpet(size);

            System.out.println("Generating Sierpinski Carpet of size " + size + ":");
            carpet.generateSierpinskiCarpet();
            carpet.printSierpinskiCarpet();
            System.out.println();


            SierpinskiCarpet carpetWithLevels = new SierpinskiCarpet(size);

            System.out.println("Generating Sierpinski Carpet with Levels of size " + size + ":");
            carpetWithLevels.generateSierpinskiCarpetWithLevels();
            carpetWithLevels.printSierpinskiCarpet();
            System.out.println("------------------------------");

        }
    }
}

import java.util.Scanner;
import java.util.Stack;

public class Interpreter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a postfix expression:");
        String postfixExpression = scanner.nextLine();

        interpretPostfixExpression(postfixExpression);

        scanner.close();
    }

    // Interpret the given postfix expression
    public static void interpretPostfixExpression(String postfixExpression) {
        Stack<Double> stack = new Stack<>();

        // Split the postfix expression into tokens
        String[] tokens = postfixExpression.split("\\s+");

        // Process each token in the expression
        for (String token : tokens) {
            if (isOperand(token)) {
                // Rule 2: Operand
                double operand = Double.parseDouble(token);
                stack.push(operand);
                System.out.println("Rule 2: Operand(" + operand + ") := " + operand);
                System.out.println("Stack: " + stack);
            } else if (isOperator(token)) {
                // Rule 1: Operator
                stack.push(applyOperator(token, stack.pop(), stack.pop()));
                System.out.println("Rule 1: Operator(" + token + ") := " + token);
                System.out.println("Stack: " + stack);
            } else {
                // Invalid token
                System.out.println("Invalid token: " + token);
                return;
            }
        }

        // Check the final result on the stack
        if (stack.size() == 1) {
            double result = stack.pop();
            System.out.println("Final result: " + result);
        } else {
            // More than one result on the stack
            System.out.println("Invalid expression. More than one result on the stack.");
        }
    }

    // Check if the token is a valid operand
    private static boolean isOperand(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Check if the token is a valid operator
    private static boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    // Apply the operator to the operands
    private static double applyOperator(String operator, double operand2, double operand1) {
        // Perform the operation based on the operator
        switch (operator) {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }
}

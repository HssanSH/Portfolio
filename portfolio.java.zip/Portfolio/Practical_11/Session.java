package Practical_11;

class Session {
    private int sessionId;
    private String location;
    private Talk[] talkList;
    private int currentSize;

    public Session(int sessionId, String location) {
        this.sessionId = sessionId;
        this.location = location;
        this.talkList = new Talk[4];
        this.currentSize = 0;
    }

    // Helper method to search for a talk by ID
    private int searchTalkIndex(int talkId) {
        for (int i = 0; i < currentSize; i++) {
            if (talkList[i] != null && talkList[i].getTalkId() == talkId) {
                return i; // Found the talk, return its index
            }
        }
        return -1; // Talk not found
    }

    // Helper method to perform sorting (bubble sort)
    private void sortTalkList() {
        for (int i = 0; i < currentSize - 1; i++) {
            for (int j = 0; j < currentSize - i - 1; j++) {
                if (talkList[j].compareTo(talkList[j + 1]) > 0) {
                    // Swap if the talks are in the wrong order
                    Talk temp = talkList[j];
                    talkList[j] = talkList[j + 1];
                    talkList[j + 1] = temp;
                }
            }
        }
    }

    public void scheduleTalk(Talk talk) {
        if (currentSize < talkList.length) {
            if (searchTalkIndex(talk.getTalkId()) == -1) {
                talkList[currentSize++] = talk;
                // Sort the talkList after adding a new talk

                sortTalkList();

            }

        } else {
            System.out.println("Cannot schedule more talks for this session.");
        }
    }

    public void cancelTalk(int talkId) {
        int talkIndex = searchTalkIndex(talkId);
        if (talkIndex != -1) {
            talkList[talkIndex] = null;

            // Sort the talkList after canceling a talk
            sortTalkList();

            currentSize--;
        } else {
            System.out.println("Practical_11.Talk with ID " + talkId + " not found in the session.");
        }
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Practical_11.Session{" +
                "sessionId=" + sessionId +
                ", location='" + location + '\'' +
                ", talkList");
        for (Talk talk : talkList) {
            if (talk != null) {
                result.append(talk.toString()).append(", ");
            }
        }
        if (currentSize > 0) {
            result.delete(result.length() - 2, result.length());
        }
        result.append("}");
        return result.toString();
    }
}

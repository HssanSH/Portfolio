package Practical_11;

class Conference {
    public static void main(String[] args) {
        // Create four sessions
        Session session1 = new Session(1, "Room A");
        Session session2 = new Session(2, "Room B");
        Session session3 = new Session(3, "Room C");
        Session session4 = new Session(4, "Room D");

        // Schedule and cancel talks for each session
        Talk talk1 = new Talk(1, "Speaker 1", "Talk 1", "2023-11-21T09:00:00");

        Talk talk2 = new Talk(2, "Speaker 2", "Talk 2", "2023-11-21T10:00:00 ");

        Talk talk3 = new Talk(3, "Speaker 3", "Talk 3", "2023-11-21T11:00:00 ");

        session1.scheduleTalk(talk1);
        session1.scheduleTalk(talk2);
        session2.scheduleTalk(talk3);

        System.out.println(session1);
        System.out.println(session2);
        System.out.println(session3);
        System.out.println(session4);
    }
}
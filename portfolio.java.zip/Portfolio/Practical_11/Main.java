package Practical_11;

class Talk implements Comparable<Talk> {
    private int talkId;
    private String speaker;
    private String title;
    private String startTime;

    public Talk(int talkId, String speaker, String title, String startTime) {
        this.talkId = talkId;
        this.speaker = speaker;
        this.title = title;
        this.startTime = startTime;
    }

    @Override
    public int compareTo(Talk otherTalk) {
        return this.startTime.compareTo(otherTalk.startTime);
    }



    @Override
    public String toString() {
        return  "\n"+"Practical_11.Talk" +
                "talkId=" + talkId +
                ", speaker=" + speaker  +
                ", title=" + title +
                ", startTime=" + startTime  ;
    }
    public int getTalkId() {
        return talkId;
    }

}




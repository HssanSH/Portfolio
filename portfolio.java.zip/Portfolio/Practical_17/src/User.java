public class User {
    public static void main(String[] args) {
        // Create an inventory system
        InventorySystem inventorySystem = new InventorySystem();

        // Use the inventory system
        User user = new User();
        user.useInventorySystem(inventorySystem);
    }

    private void useInventorySystem(InventorySystem inventorySystem) {
        // Predefined orders
        Order order1 = new Order(101, "ProductX", 10.99, 3);
        Order order2 = new Order(102, "ProductY", 20.49, 2);
        Order order3 = new Order(103, "ProductZ", 15.75, 1);
        Order order4 = new Order(104, "ProductW", 45.6, 5);
        Order order5 = new Order(105, "ProductV", 9.5, 4);
        Order order6 = new Order(106, "ProductU", 13.86, 7);

        // Place predefined orders
        inventorySystem.placeOrUpdateOrder(order1);
        inventorySystem.placeOrUpdateOrder(order2);
        inventorySystem.placeOrUpdateOrder(order3);
        inventorySystem.placeOrUpdateOrder(order4);
        inventorySystem.placeOrUpdateOrder(order5);
        inventorySystem.placeOrUpdateOrder(order6);

        // Print details of each order
        System.out.println("Orders placed:");
        System.out.println(order1);
        System.out.println(order2);
        System.out.println(order3);
        System.out.println(order4);
        System.out.println(order5);
        System.out.println(order6);

        // Cancel an order
        inventorySystem.cancelOrder(103);

        // Update an order
        Order updatedOrder = new Order(101, "ProductX", 10.99, 3);
        updatedOrder.setStatus("PAID");
        inventorySystem.placeOrUpdateOrder(updatedOrder);

        // Print orders with 'Pending' status after update
        System.out.println("\nOrder updated:");
        inventorySystem.printOrdersByStatus("PAID");

        // Track an order
        Order trackedOrder = inventorySystem.trackOrder(102);

        // Print tracked order details
        System.out.println("\nTracking Order ID 102:");
        if (trackedOrder != null) {
            System.out.println(trackedOrder);
        } else {
            System.out.println("Order ID 102 not found. Cannot track.");
        }

        // Print orders by status
        System.out.println("\nOrders with status PENDING:");
        inventorySystem.printOrdersByStatus("PENDING");
        System.out.println("\nOrders with status PAID:");
        inventorySystem.printOrdersByStatus("PAID");
        System.out.println("\nOrders with status SHIPPED:");
        inventorySystem.printOrdersByStatus("SHIPPED");
        System.out.println("\nOrders with status DELIVERED:");
        inventorySystem.printOrdersByStatus("DELIVERED");
        System.out.println("\nOrders with status REFUNDED:");
        inventorySystem.printOrdersByStatus("REFUNDED");

        // Calculate and print total revenue
        double totalRevenue = inventorySystem.calculateTotalRevenue();
        System.out.println("\nTotal Revenue for Inventory System: $" + totalRevenue);
    }
}

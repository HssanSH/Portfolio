import java.util.HashMap;
import java.util.Map;
public class InventorySystem {
    private Map<Integer, Order> orders = new HashMap<>();

    public void placeOrUpdateOrder(Order order) {
        orders.put(order.getOrderId(), order);
    }

    public void cancelOrder(int orderId) {
        orders.remove(orderId);
    }

    public Order trackOrder(int orderId) {
        return orders.get(orderId);
    }

    public void printOrdersByStatus(String status) {
        System.out.println("Orders with Status '" + status + "':");
        for (Order order : orders.values()) {
            if (order.getStatus().equals(status)) {
                System.out.println(order);
            }
        }
    }

    public double calculateTotalRevenue() {
        double totalRevenue = 0.0;
        for (Order order : orders.values()) {
            totalRevenue += order.getProductPrice() * order.getQuantity();
        }
        return totalRevenue;
    }
}

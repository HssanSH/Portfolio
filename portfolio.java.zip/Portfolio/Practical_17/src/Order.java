import java.util.Objects;  // Import required utility for Objects class

import java.util.HashMap;
import java.util.Map;

public class Order {
    private int orderId;
    private String productName;
    private double productPrice;
    private int quantity;
    private String status;

    public Order(int orderId, String productName, double productPrice, int quantity) {
        this.orderId = orderId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.status = "Pending";
    }

    public int getOrderId() {
        return orderId;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId +
                ", Product: " + productName +
                ", Price per Item: " + productPrice +
                ", Quantity: " + quantity +
                ", Status: " + status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return orderId == order.orderId &&
                Double.compare(order.productPrice, productPrice) == 0 &&
                quantity == order.quantity &&
                productName.equals(order.productName) &&
                status.equals(order.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, productName, productPrice, quantity, status);
    }
}
public class User {
    public static void main(String[] args) {
        // Create an inventory system
        InventorySystem inventorySystem = new InventorySystem();

        // Use the inventory system
        User user = new User();
        user.useInventorySystem(inventorySystem);
    }

    // Helper method to use the inventory system
    private void useInventorySystem(InventorySystem inventorySystem) {
        Order order1 = new Order(1, "ProductA", 10.0, 3);
        Order order2 = new Order(2, "ProductB", 15.0, 2);

        inventorySystem.placeOrUpdateOrder(order1);
        inventorySystem.placeOrUpdateOrder(order2);

        inventorySystem.printOrdersByStatus("Pending");

        Order updatedOrder = new Order(1, "ProductA", 10.0, 5);
        inventorySystem.placeOrUpdateOrder(updatedOrder);

        inventorySystem.printOrdersByStatus("Pending");

        inventorySystem.cancelOrder(2);

        inventorySystem.printOrdersByStatus("Pending");

        Order trackedOrder = inventorySystem.trackOrder(1);
        System.out.println("Tracked Order: " + trackedOrder);

        inventorySystem.printOrdersByStatus("Pending");

        double totalRevenue = inventorySystem.calculateTotalRevenue();
        System.out.println("Total Revenue: $" + totalRevenue);
    }
}
